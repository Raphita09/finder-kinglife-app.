import 'package:flutter/material.dart';

void main() {
  runApp(const FinderKingLifeApp());
}

class FinderKingLifeApp extends StatelessWidget {
  const FinderKingLifeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Finder King Life',
      theme: ThemeData(
        primarySwatch: Colors.green,
        brightness: Brightness.light,
      ),
      home: const Scaffold(
        body: Center(child: Text('¡Bienvenido a Finder King Life!')),
      ),
    );
  }
}
